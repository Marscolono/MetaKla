import numpy as np
import pandas as pd 

#>Label:1|Protein_id:Q8IVF6|K_position:911|Protein_name:Ankyrin repeat domain-containing protein 18A|Gene_name:ANKRD18A|PubMed_id:14702039,32201722
#EAFAGAVKANNSMSKKLMKSDKKIAVISTKL
#>Label:1|Protein_id:Q8IVF6|K_position:914|Protein_name:Ankyrin repeat domain-containing protein 18A|Gene_name:ANKRD18A|PubMed_id:14702039,32201722
#AGAVKANNSMSKKLMKSDKKIAVISTKLFTE

def Add_FASTAheader_N(data,PosNeg):
	#创建只有+sample或者-sample的fast格式：c
	if PosNeg =='+':
		c = [">" + 'Label:1|Protein']*len(data)
	elif PosNeg =='-':
		c = [">" + 'Label:0|Protein']*len(data)
		
	a = list(zip(c,data))   #以上的代码可以用这句替代，变成了二维列表，[('<0', '11111'), ('<1', '22222')]
	combin = [n for i in a for n in i  ]   #python把二维列表变为一维列表的方法
	return combin

species = 'Kla'
path = '/home/lz/New/0Meta_project/Datasets/{0}_data/{0}_train_test/'.format(species)


def creat_data(path,state):
	data_pos = np.loadtxt(path + '{0}_positive_{1}.fa'.format(species,state),dtype = list)
	data_neg = np.loadtxt(path + '{0}_negative_{1}.fa'.format(species,state),dtype = list)
	
	X_pos = pd.DataFrame(Add_FASTAheader_N(data_pos,'+'))
	X_neg = pd.DataFrame(Add_FASTAheader_N(data_neg,'-'))
	res = pd.concat([X_pos, X_neg], axis=0)
	print(res)
	return res

OutputDir = '/home/lz/New/0Meta_project/Datasets/{0}_data/{0}_data/'.format(species)
import os
if os.path.exists(OutputDir):
	print('yes')
else:
	os.makedirs(OutputDir)
	print('success create dir test')
	
# for i in range(5):
res_train = creat_data(path,'train')
res_test = creat_data(path,'test')

res_train.to_csv(OutputDir + "{0}_{1}_Bert.txt".format(species,'train'), index=False,header=False, sep='\t')
res_test.to_csv(OutputDir + "{0}_{1}_Bert.txt".format(species,'test'), index=False,header=False, sep='\t')

